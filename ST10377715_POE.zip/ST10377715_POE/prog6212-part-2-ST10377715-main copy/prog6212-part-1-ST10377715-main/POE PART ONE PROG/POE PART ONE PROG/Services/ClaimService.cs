﻿using POE_PART_ONE_PROG.Models; // Ensure this matches your actual namespace

public class ClaimService
{
    private readonly List<Claim> _claims = new List<Claim>();

    public List<Claim> GetAllClaims() => _claims;

    public void AddClaim(Claim claim)
    {
        claim.Id = _claims.Count + 1;
        _claims.Add(claim);
    }

    public Claim GetClaimById(int id)
    {
        return _claims.FirstOrDefault(c => c.Id == id);
    }

    public void UpdateClaim(Claim updatedClaim)
    {
        var claim = _claims.FirstOrDefault(c => c.Id == updatedClaim.Id);
        if (claim != null)
        {
            claim.Status = updatedClaim.Status;
            // Update other fields if needed
        }
    }
}
