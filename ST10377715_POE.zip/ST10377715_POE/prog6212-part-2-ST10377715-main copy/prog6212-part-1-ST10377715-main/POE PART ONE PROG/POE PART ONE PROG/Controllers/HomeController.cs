using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    public IActionResult Index() => View();

    [HttpPost]
    public async Task<IActionResult> SubmitClaim(int hoursWorked, decimal hourlyRate, string notes, IFormFile supportingDocument)
    {
        if (supportingDocument != null && supportingDocument.Length > 0)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", supportingDocument.FileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await supportingDocument.CopyToAsync(stream);
            }
        }
        return RedirectToAction("ClaimSubmitted");
    }

    public IActionResult ClaimSubmitted() => View();
}
