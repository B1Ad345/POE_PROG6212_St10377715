﻿using Microsoft.AspNetCore.Mvc;
using POE_PART_ONE_PROG.Models;  // Add this line to reference Claim class

public class MusicianController : Controller
{
    private readonly ClaimService _claimService;

    public MusicianController(ClaimService claimService)
    {
        _claimService = claimService;
    }

    public IActionResult Index()
    {
        var claims = _claimService.GetAllClaims();
        return View(claims);
    }

    [HttpPost]
    public async Task<IActionResult> SubmitClaim(string musicianName, int hoursWorked, decimal hourlyRate, string notes, IFormFile supportingDocument)
    {
        string fileName = null;

        if (supportingDocument != null && supportingDocument.Length > 0)
        {
            fileName = Path.GetFileName(supportingDocument.FileName);
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await supportingDocument.CopyToAsync(stream);
            }
        }

        var newClaim = new Claim
        {
            MusicianName = musicianName,
            HoursWorked = hoursWorked,
            HourlyRate = hourlyRate,
            Notes = notes,
            Status = "Pending",
            SupportingDocument = fileName
        };

        _claimService.AddClaim(newClaim);
        return RedirectToAction("Index");
    }
}
