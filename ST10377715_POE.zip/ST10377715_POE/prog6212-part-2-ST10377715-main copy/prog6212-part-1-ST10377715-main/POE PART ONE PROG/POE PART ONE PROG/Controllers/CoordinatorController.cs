﻿using Microsoft.AspNetCore.Mvc;

public class CoordinatorController : Controller
{
    private readonly ClaimService _claimService;

    public CoordinatorController(ClaimService claimService)
    {
        _claimService = claimService;
    }

    public IActionResult Index()
    {
        var claims = _claimService.GetAllClaims();
        return View(claims);
    }

    [HttpPost]
    public IActionResult Approve(int id)
    {
        var claim = _claimService.GetClaimById(id);
        if (claim != null)
        {
            claim.Status = "Approved";
            _claimService.UpdateClaim(claim);
        }
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Reject(int id)
    {
        var claim = _claimService.GetClaimById(id);
        if (claim != null)
        {
            claim.Status = "Rejected";
            _claimService.UpdateClaim(claim);
        }
        return RedirectToAction("Index");
    }
}
