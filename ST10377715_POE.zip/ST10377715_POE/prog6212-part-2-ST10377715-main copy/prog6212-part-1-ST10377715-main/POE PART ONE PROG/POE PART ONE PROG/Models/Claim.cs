﻿namespace POE_PART_ONE_PROG.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public string MusicianName { get; set; }
        public int HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string Notes { get; set; }
        public string Status { get; set; }
        public string SupportingDocument { get; set; }
        public DateTime DateSubmitted { get; set; } = DateTime.Now;
    }
}
