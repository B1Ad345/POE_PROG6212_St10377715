using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace POE_PART_ONE_PROG.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // Simple dummy login (replace with your actual authentication system)
            if (username == "musician" && password == "password")
            {
                HttpContext.Session.SetString("Role", "Musician");
                return RedirectToAction("Index", "Musician");
            }
            else if (username == "coordinator" && password == "password")
            {
                HttpContext.Session.SetString("Role", "Coordinator");
                return RedirectToAction("Index", "Coordinator");
            }
            else
            {
                TempData["ErrorMessage"] = "Invalid credentials";
                return RedirectToAction("Index");
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}
