﻿using Microsoft.AspNetCore.Mvc;
using POE_PART_ONE_PROG.Models;
using POE_PART_ONE_PROG.Services;
using System.Linq;

namespace POE_PART_ONE_PROG.Controllers
{
    public class CoordinatorController : Controller
    {
        private readonly ClaimService _claimService;

        public CoordinatorController(ClaimService claimService)
        {
            _claimService = claimService;
        }

        public IActionResult Index()
        {
            var claims = _claimService.GetAllClaims().Where(c => c.Status == "Pending").ToList();
            return View(claims);
        }

        public IActionResult Approve(int id)
        {
            var claim = _claimService.GetClaimById(id);
            if (claim != null && claim.Status == "Pending")
            {
                claim.Status = "Approved";
                _claimService.UpdateClaim(claim);
                var invoice = _claimService.GenerateInvoice(claim);
                ViewBag.Invoice = invoice;
            }
            return View(claim);
        }

        public IActionResult Reject(int id)
        {
            var claim = _claimService.GetClaimById(id);
            if (claim != null && claim.Status == "Pending")
            {
                claim.Status = "Rejected";
                _claimService.UpdateClaim(claim);
            }
            return RedirectToAction("Index");
        }
    }
}
