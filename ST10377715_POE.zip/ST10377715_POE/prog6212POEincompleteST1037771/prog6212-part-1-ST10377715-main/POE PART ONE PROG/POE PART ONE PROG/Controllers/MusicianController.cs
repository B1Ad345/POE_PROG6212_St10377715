﻿using Microsoft.AspNetCore.Mvc;
using POE_PART_ONE_PROG.Models;
using POE_PART_ONE_PROG.Services;
using System.Linq;

namespace POE_PART_ONE_PROG.Controllers
{
    public class MusicianController : Controller
    {
        private readonly ClaimService _claimService;

        public MusicianController(ClaimService claimService)
        {
            _claimService = claimService;
        }

        public IActionResult Index()
        {
            var claims = _claimService.GetAllClaims().Where(c => c.MusicianName == "musician").ToList();
            return View(claims);
        }

        [HttpPost]
        public IActionResult SubmitClaim(Claim claim)
        {
            if (!_claimService.IsHourlyRateValid(claim.HourlyRate))
            {
                claim.Status = "Rejected";
            }
            else
            {
                claim.Status = "Pending";
            }

            _claimService.AddClaim(claim);
            return RedirectToAction("Index");
        }
    }
}
