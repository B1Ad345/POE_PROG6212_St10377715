﻿public class Invoice
{
    public int InvoiceID { get; set; }
    public string MusicianName { get; set; }
    public decimal Amount { get; set; }
    public string Status { get; set; }
}
