﻿using POE_PART_ONE_PROG.Models;
using System.Collections.Generic;

namespace POE_PART_ONE_PROG.Services
{
    public class ClaimService
    {
        private readonly List<Claim> claims = new List<Claim>();
        private int invoiceCounter = 1;

        // Retrieve all claims
        public List<Claim> GetAllClaims() => claims;

        // Add a new claim
        public void AddClaim(Claim claim)
        {
            claims.Add(claim);
        }

        // Get claim by ID
        public Claim GetClaimById(int id) => claims.Find(c => c.Id == id);

        // Update claim status and document
        public void UpdateClaim(Claim claim)
        {
            var existingClaim = GetClaimById(claim.Id);
            if (existingClaim != null)
            {
                existingClaim.Status = claim.Status;
                existingClaim.SupportingDocument = claim.SupportingDocument;
            }
        }

        // Generate invoice for approved claims
        public string GenerateInvoice(Claim claim)
        {
            decimal totalAmount = claim.HoursWorked * claim.HourlyRate;
            return $"Invoice #{invoiceCounter++}: {claim.MusicianName} - Amount: ${totalAmount} - Status: {claim.Status}";
        }

        // Validate hourly rate (minimum 10, maximum 100)
        public bool IsHourlyRateValid(decimal hourlyRate)
        {
            const decimal minRate = 10;
            const decimal maxRate = 100;
            return hourlyRate >= minRate && hourlyRate <= maxRate;
        }
    }
}
